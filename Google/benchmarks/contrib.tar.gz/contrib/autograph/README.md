# AutoGraph

**NOTE: As tensorflow.contrib is being
[deprecated](https://github.com/tensorflow/community/pull/18), AutoGraph is
moving into TensorFlow core.

The new code location is `tensorflow/python/autograph`. Please refer to the
README.md file in that directory.
**
