The contrib/quantization package exposes a few TensorFlow quantization operations.

If you are looking for quantized training rewrites that allow for training
quantized models that work with
[TensorFlow Lite](https://www.tensorflow.org/lite/), you should look at
the [contrib/quantize](https://www.tensorflow.org/api_docs/python/tf/contrib/quantize)
package.
