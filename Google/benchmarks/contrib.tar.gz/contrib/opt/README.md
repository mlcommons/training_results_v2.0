# Optimization package

Contains the following experimental optimization functionality:

 *  Support for controlling a TensorFlow session using external optimization
    algorithms.
 *  L2-norm clipping of weights

Maintainer: joshburkart
